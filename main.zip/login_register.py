import mysql.connector

# Kelas dasar untuk input data
class CustomerDataInput:
    def __init__(self, db_name):
        self.db_name = db_name

    def delete_data(self):
        raise NotImplementedError("Metode delete_data harus diimplementasikan!")

    def update_data(self):
        raise NotImplementedError("Metode update_data harus diimplementasikan!")
            
    def close_program(self):
        print("\nProgram ditutup.")


class SQLDataCustomer(CustomerDataInput):
    def __init__(self, db_name, customer_table_name):
        super().__init__(db_name)
        self.customer_table_name = customer_table_name

    def delete_data(self):
        # Membuat koneksi ke database
        conn = mysql.connector.connect(
            host = "localhost",
            user = "root",
            password = "",
            database = self.db_name)
        c = conn.cursor()

        # Menampilkan data yang ada dalam database
        print("Data saat ini:")
        c.execute(f"SELECT * FROM {self.customer_table_name}")
        rows = c.fetchall()
        for row in rows:
            print(row)

        # Menerima input data yang akan dihapus
        id_to_delete = int(input("Masukkan Nomor KTP yang akan dihapus: "))

        # Konfirmasi apakah akan benar akan menghapus data
        confirm = str(input("Apakah anda yakin ingin menghapus data? (y/n): "))
        if confirm == 'y':
            # Menghapus data dari database
            c.execute(f"DELETE FROM {self.customer_table_name} WHERE no_ktp=%s", (id_to_delete,))
            conn.commit()
        else:
            customer = SQLDataCustomer("servismobil", "customer")
            customer.delete_data()

        # Menampilkan data setelah penghapusan
        # print("Data setelah penghapusan:")
        # c.execute(f"SELECT * FROM {self.customer_table_name}")
        # rows = c.fetchall()
        # for row in rows:
        #     print(row)

        # Menutup koneksi database
        conn.close()

    def update_data(self):
        # Membuat koneksi ke database
        conn = mysql.connector.connect(
            host = "localhost",
            user = "root",
            password = "",
            database = self.db_name)
        c = conn.cursor()

        # Menampilkan data yang ada dalam database
        print("\nData saat ini:")
        print("==============================================")
        c.execute(f"SELECT * FROM {self.customer_table_name}")
        rows = c.fetchall()
        for row in rows:
            print(row)

        # Menerima input data yang akan diperbarui
        no_ktp = int(input("\nMasukkan Nomor KTP yang akan diperbarui: "))
        new_no_ktp = int(input("Masukkan Nomor KTP baru: "))
        new_nama = input("Masukkan Nama baru: ")
        new_alamat = str(input("Masukkan Alamat baru: "))

        # Memperbarui data di database
        c.execute(f"UPDATE {self.customer_table_name} SET no_ktp=%s, nama_customer=%s, alamat_customer=%s WHERE no_ktp=%s", (new_no_ktp, new_nama, new_alamat, no_ktp))
        conn.commit()

        # Menampilkan data setelah pembaruan
        print("\nData setelah pembaruan:")
        
        c.execute(f"SELECT * FROM {self.customer_table_name} WHERE no_ktp = %s AND nama_customer = %s", (new_no_ktp, new_nama))
        
        result = c.fetchone()
        if result:
            print("Nomor KTP:", result[0])
            print("Nama:", result[1])
            print("Alamat:", result[2], "\n\n")
        else:
            print("Data customer tidak ditemukan.")
        
        # Menutup koneksi database
        conn.close()






def access():
    option = begin()
    if option == "login":
        no_ktp = input("Masukkan Nomor KTP: ")
        nama_customer = input("Masukkan Nama: ")
        login(no_ktp, nama_customer)
    elif option == "reg":
        print("\nMasukkan Nomor KTP dan Nama anda yang baru")
        no_ktp = input("Masukkan Nomor KTP: ")
        nama_customer = input("Masukkan Nama: ")
        alamat_customer = input("Masukkan Alamat: ")
        register(no_ktp, nama_customer, alamat_customer)
        print("==============================================")
        print("Register Berhasil, Silakan Login")
    
    elif option == "update":
        customer = SQLDataCustomer("servismobil", "customer")
        customer.update_data()
    
    elif option == "delete":
        customer = SQLDataCustomer("servismobil", "customer")
        customer.delete_data()


def begin():
    print("\nSELAMAT DATANG")
    print("\nKETIK 'login' JIKA SUDAH PUNYA AKUN")
    print("KETIK 'update' JIKA INGIN MENGUBAH AKUN")
    print("KETIK 'delete' JIKA INGIN MENGHAPUS AKUN")
    print("KETIK 'reg' JIKA BELUM PUNYA AKUN")

    while True:
        option = input("\nSilakan masukkan (login/update/delete/reg): ")
        if option == "login" or option == "reg" or option == "update" or option == "delete":
            break

    return option

def login(no_ktp, nama_customer):
    
    file = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="servismobil"
    )
    c = file.cursor()

    c.execute("SELECT * FROM customer WHERE no_ktp = %s AND nama_customer = %s", (no_ktp, nama_customer))
    result = c.fetchone()

    if result:
        print("==============================================")
        print("Login Berhasil")
    else:
        print("Anda Belum Terdaftar, Silakan Register")
        
    file.close()

    return no_ktp

def register(no_ktp, nama_customer, alamat_customer):
    file = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="servismobil"
    )
    c = file.cursor()
    c.execute("INSERT INTO customer(no_ktp, nama_customer, alamat_customer) VALUES (%s, %s, %s)", (no_ktp, nama_customer, alamat_customer))
    file.commit()
    file.close()

    return no_ktp